// In-memory storage for shipment data
const shipments = [];

module.exports = shipments;
