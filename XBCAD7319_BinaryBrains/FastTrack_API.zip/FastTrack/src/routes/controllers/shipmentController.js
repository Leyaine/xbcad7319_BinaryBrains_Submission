const shipments = require('../models/Shipment');
let idCounter = 1; // To generate unique IDs for shipments

// Create a new shipment
exports.createShipment = (req, res) => {
    const { trackingNumber, status } = req.body;

    if (!trackingNumber) {
        return res.status(400).json({ message: 'Tracking number is required' });
    }

    const newShipment = {
        id: idCounter++,
        trackingNumber,
        status: status || 'Pending',
        createdAt: new Date(),
    };

    shipments.push(newShipment);
    res.status(201).json(newShipment);
};

// Get all shipments
exports.getShipments = (req, res) => {
    res.status(200).json(shipments);
};

// Update a shipment's status
exports.updateShipment = (req, res) => {
    const { id } = req.params;
    const { status } = req.body;

    const shipment = shipments.find((s) => s.id === parseInt(id));

    if (!shipment) {
        return res.status(404).json({ message: 'Shipment not found' });
    }

    shipment.status = status || shipment.status;
    res.status(200).json(shipment);
};

// Delete a shipment
exports.deleteShipment = (req, res) => {
    const { id } = req.params;

    const index = shipments.findIndex((s) => s.id === parseInt(id));
    if (index === -1) {
        return res.status(404).json({ message: 'Shipment not found' });
    }

    shipments.splice(index, 1);
    res.status(200).json({ message: 'Shipment deleted successfully' });
};
