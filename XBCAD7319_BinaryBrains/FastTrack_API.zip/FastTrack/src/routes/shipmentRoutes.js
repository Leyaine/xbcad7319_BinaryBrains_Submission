const express = require('express');
const {
    createShipment,
    getShipments,
    updateShipment,
    deleteShipment,
} = require('../controllers/shipmentController');

const router = express.Router();

// POST: Create a shipment
router.post('/', createShipment);

// GET: Retrieve all shipments
router.get('/', getShipments);

// PUT: Update a shipment by ID
router.put('/:id', updateShipment);

// DELETE: Delete a shipment by ID
router.delete('/:id', deleteShipment);

module.exports = router;
